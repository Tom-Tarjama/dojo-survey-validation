from flask import Flask, render_template, redirect, request, flash

dojo_survey = Flask(__name__)
dojo_survey.secret_key="ThisIsSecret"

@dojo_survey.route('/')
def form():
	return render_template("index.html")

@dojo_survey.route("/result", methods=['POST'])
def submit():
	name = request.form["name"]
	location = request.form["location"]
	language = request.form["language"]
	comment = request.form["comment"]
	print name, location, language, comment
	# return redirect("/")
	if len(name) < 1 and len(comment) <1:
		flash("Cannot leave name field empty")
		flash("Cannot leave comment field empty")
	elif len(comment) > 120 and len(name) < 1:
		flash("Cannot leave name field empty")
		flash("Your comment is too long!")
	elif len(comment) < 1:
		flash("Cannot leave comment field empty")
	elif len(name) < 1:
		flash("Cannot leave name field empty")
	elif len(comment) > 120:
		flash("Your comment is too long!")
	else:
		flash("Submission successful. Thank you!")

	return render_template("result.html", display_name=name, display_location=location, display_language=language, display_comment=comment)

dojo_survey.run(debug=True)
